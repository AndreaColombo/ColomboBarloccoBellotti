
#include "registers.h"
#include "serial.h"

//PD14: red led

void delay()
{
	volatile int i;
	for(i=0;i<1000000;i++) ;
}

SerialPort serial;
//serial = new SerialPort();
int main()
{
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
		bool led=false;
	for(int n=0;;)
	{
		GPIOD->MODER |= 1<<(24+n*2);
	//	serial.write("Hello world\r\n");
		delay();
		if(led) GPIOD->BSRR=1<<(12+n);
		else GPIOD->BSRR=1<<(12+n+16);
		led=!led;
		if (n==4)
			n=0;
		else n++;
	}
}
